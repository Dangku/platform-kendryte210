
#ifndef __ARDUINO_SPI_HAL_H
#define __ARDUINO_SPI_HAL_H

#define SPI_MUTEX_LOCK() 
#define SPI_MUTEX_UNLOCK() 


#endif //__ARDUINO_SPI_HAL_H



