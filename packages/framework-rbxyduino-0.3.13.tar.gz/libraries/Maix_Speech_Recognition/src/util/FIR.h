#ifndef _FIR_H_
#define _FIR_H_

#ifdef __cplusplus
extern "C" {
#endif


double Fir(double Input);

#ifdef __cplusplus
}
#endif

#endif
